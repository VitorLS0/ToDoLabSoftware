package com.example.ToDoLabSoftware.model;

public enum Priority {
    HIGH, MEDIUM, LOW
}
