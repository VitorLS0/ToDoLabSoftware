package com.example.ToDoLabSoftware.model;

public enum TaskType {
    SPECIFIC_DATE, COUNTED_DAYS, NO_ESTIMATED_TIME
}